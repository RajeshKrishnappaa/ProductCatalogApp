﻿namespace ProdApp.Models
{
    public class ProductImage
    {
        public IFormFile ImageFile { get; set; }

    }
}
